import os
import pickle
import numpy as np
import face_recognition
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Load stored images
data = []
labels = []

for student in os.listdir(r"C:\Users\sri dattu\Desktop\Face (2)\Face (2)\Face (2)\Face\backend\images"):
    folder_path = os.path.join(r"C:\Users\sri dattu\Desktop\Face (2)\Face (2)\Face (2)\Face\backend\images", student)
    
    for file in os.listdir(folder_path):
        img_path = os.path.join(folder_path, file)
        img = face_recognition.load_image_file(img_path)
        
        face_encodings = face_recognition.face_encodings(img)
        if face_encodings:
            data.append(face_encodings[0])
            labels.append(student)

# Convert to NumPy arrays
data = np.array(data)
labels = np.array(labels)

# 1. Split the data (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, stratify=labels, random_state=42)

# 2. Train SVM model
svm_model = SVC(kernel="linear", probability=True)
svm_model.fit(X_train, y_train)

# 3. Predict on test data
y_pred = svm_model.predict(X_test)

# 4. Evaluate
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# 5. Save the trained model
with open("trained_svm.pkl", "wb") as f:
    pickle.dump(svm_model, f)

print("✅ Training complete. Model saved as trained_svm.pkl")
