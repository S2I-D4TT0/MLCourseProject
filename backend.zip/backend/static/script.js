document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('liveVideo');
    const notificationList = document.getElementById('notificationList');
    const addStudentButton = document.getElementById('addStudentButton');
    const checkStatusButton = document.getElementById('checkStatusButton');

    // Access webcam
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
            video.play();
            startFrameCapture(); // Start capturing frames
        })
        .catch(error => {
            console.error('Error accessing webcam:', error);
            alert('Failed to access webcam. Please allow camera permissions and refresh the page.');
        });

    // WebSocket connection
    const socket = io();

    // Function to capture and send video frames
    function startFrameCapture() {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');

        setInterval(() => {
            // Only proceed if video is actually playing
            if (video.readyState !== video.HAVE_ENOUGH_DATA) {
                return;
            }
            
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            // Convert canvas image to base64
            const frame = canvas.toDataURL('image/jpeg', 0.7);

            // Send frame to backend via WebSocket
            socket.emit('video_frame', { frame: frame });
        }, 1000); // Send a frame every second
    }

    // Receive notifications
    socket.on('notification', function(data) {
        const li = document.createElement('li');
        li.textContent = `${data.enrollment_number} ${data.status} at ${data.timestamp}`;
        notificationList.appendChild(li);
        notificationList.scrollTop = notificationList.scrollHeight;
    });

    // Add Student button click event - redirect to add_student.html
    addStudentButton.addEventListener('click', function() {
        window.location.href = '/add_student';
    video.srcObject.getTracks().forEach(track => track.stop());
    window.location.href = '/add_student';
    });

    // Check Status button click event - redirect to status page
    checkStatusButton.addEventListener('click', function() {
        window.location.href = '/status_page';
    });
});